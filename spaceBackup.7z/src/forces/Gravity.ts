import { Force } from '../core/Force';
import { Constants } from '../core/Constants'

export class Gravity extends Force
{
  constructor()
  {
    super(0,Constants.GroundGravityForce);
  }
}