export const Constants =
{
  DebugMode : true,
  GroundGravityForce : 0.05,
  UnitsPerMeter:68,
  UnitsPerFeet:20.72639
}