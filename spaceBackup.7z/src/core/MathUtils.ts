import { Constants } from '../core/Constants'

export class MathUtils {

  static AltitudeToFeet(altitude: number): number {
    return altitude / Constants.UnitsPerFeet;
  }

  static Map(inValue: number, inMin: number, inMax: number, outMin: number, outMax: number) {
    return (inValue - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
  }

  static MillisecondsToTime(timeInMilliseconds: number): string {

    var SS:string = (Math.round((timeInMilliseconds / 1000) % 60)).toString();
    var MM:string = (Math.round((timeInMilliseconds / (1000 * 60)) % 60).toString();

    SS = SS.length == 1 ? '0'+SS:SS;
    MM = MM.length == 1 ? '0'+MM:MM;

    return MM+':'+SS;
  }

}