export class Force extends Phaser.Math.Vector2
{
  constructor(_x:number,_y:number)
  {
    super(_x,_y);
  }

  mul(value:number)
  {
    this.x *= value;
    this.y *= value;
  }

  div(value:number)
  {
    this.x /= value;
    this.y /= value;
  }

  outMul(value:number):Force{
    var xCalc = this.x * value;
    var yCalc = this.y * value;
    return new Force(xCalc,yCalc);
  }

  outDiv(value:number):Force{
    var xCalc = this.x / value;
    var yCalc = this.y / value;
    return new Force(xCalc,yCalc);
  }

}