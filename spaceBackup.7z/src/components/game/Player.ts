import { GameData } from '../../core/GameData';
import { Force } from '../../core/Force';
import { MathUtils } from '../../core/MathUtils';

export class Player extends Phaser.GameObjects.Container {

  private headSprite!: Phaser.GameObjects.Sprite;
  private engineSprite!: Phaser.GameObjects.Sprite;
  private bodySprite!: Phaser.GameObjects.Sprite;
  private finsSprite!: Phaser.GameObjects.Sprite;
  private boosterSprite!: Phaser.GameObjects.Sprite;

  private keys!: any;

  private acceleration: Phaser.Math.Vector2 = new Phaser.Math.Vector2(0, 0);
  private velocity: Phaser.Math.Vector2 = new Phaser.Math.Vector2(0, 0);
  private drag: Force = new Force(0,0);
  private altitude: number = 0;
  private speed:number = 0;
  private verticalSpeed:number = 0;
  private maxSpeed = 0;
  private terminalFallVelocity = 0;
  private airDensity = 1;
  private actualEnginePower:number = 1;
  private dryWeight:number;
  private maxWeight:number;
  private flightTime:number = 0;
  private totalMoney:number = 0;

  private isMainEngineOn:boolean = true;
  private isBoosterOn:boolean = false;
  private isBoosterOverheated = false;

  private isDebugMode = false;
  private debugGraphics!: Phaser.GameObjects.Graphics;

  private hp:number;
  private armor:number;
  private weight:number;
  private power:number;
  private maxFuel:number;
  private fuel:number;
  private fuelConsumption:number;
  private boosterPower:number;
  private maxBoosterFuel:number;
  private boosterFuel:number;
  private boosterFuelConsumption:number;
  private boosterOverheating:number;
  private boosterMaxTemperature:number;
  private handling:number;
  private airResistance:number;

  constructor(_scene: Phaser.Scene, _x: number, _y: number,debugMode:boolean) {
    super(_scene, _x, _y);

    this.isDebugMode = debugMode;
    this.loadPlayerSprites();

    // Load player parameters
    this.hp = 200;
    this.armor = 1;
    this.weight = 10000;
    this.power = 4.09;
    this.fuel = 25000;
    this.maxFuel = this.fuel;
    this.fuelConsumption = 0.5;
    this.boosterPower = 0.15;
    this.boosterFuel = 10;
    this.maxBoosterFuel = this.boosterFuel;
    this.boosterFuelConsumption = 0.1;
    this.boosterOverheating = 0;
    this.boosterMaxTemperature = 20;
    this.handling = 0.01;
    this.airResistance = 1;

    this.maxSpeed = 0.2;
    this.dryWeight = this.weight*0.1;
    this.maxWeight = this.weight;
    this.updateAltitude();

    if( this.isDebugMode ){
      this.setAlpha(0.5);
      this.debugGraphics = _scene.add.graphics();
    }

  }

  public update(time: number, delta: number) {

    this.updateThrust();
    this.updateBoosterThrust();
    this.updateDrag();
    this.updatePositionAndSpeed();
    this.updateFuelConsumptionAndWeight();
    this.updateAltitude();
    this.updateTimeAndMoney(delta);

  }

  private updateThrust(){
    if( this.isMainEngineOn )
    {
      if (this.fuel > 0) {
        var thrustForce: Force = new Force(Math.sin(this.rotation), -Math.cos(this.rotation));
        thrustForce.mul(this.updateEnginePower());
        this.applyForce(thrustForce.outMul(this.weight));
      }
    }
  }

  private updateEnginePower():number{
    this.actualEnginePower = MathUtils.Map(this.weight,this.maxWeight,this.dryWeight,this.power,this.power*2);
    return this.actualEnginePower;
  }

  private updateBoosterThrust(){
    if( this.isBoosterOn ){
      if( this.boosterFuel > 0 && !this.isBoosterOverheated ){
        var thrustForce: Force = new Force(Math.sin(this.rotation), -Math.cos(this.rotation));
        thrustForce.mul(this.boosterPower);
        this.updateBoosterTemperature();
        this.applyForce(thrustForce.outMul(this.weight));
      }
    }else{
      this.updateBoosterTemperature();
    }
  }

  private updateBoosterTemperature(){
    if( this.isBoosterOn ){
      this.boosterOverheating += 0.5;
    }else{
      if( this.boosterOverheating > 0 ){
        this.boosterOverheating -= 0.5;

      }
      if( this.boosterOverheating < 0 ){
        this.boosterOverheating = 0;
      }
    }

    if( this.boosterOverheating == this.boosterMaxTemperature ){
      this.isBoosterOverheated = true;
    }

    if( this.boosterOverheating == 0 ){
      this.isBoosterOverheated = false;
    }

  }

  private updateDrag(){
    var dragForce:Force = new Force(this.velocity.x*-1,this.velocity.y*-1);
    dragForce.mul(0.5);
    dragForce.mul(this.airDensity);
    dragForce.mul(this.speed*this.speed);
    this.drag = dragForce;

    this.applyForce(this.drag);
  }

  private updateAltitude(){
    this.altitude = this.y * -1;
  }

  private updateFuelConsumptionAndWeight(){

    if( this.isMainEngineOn )
    {
      this.fuel -= this.fuelConsumption;
    }

    if( this.isBoosterOn )
    {
      this.boosterFuel -= this.boosterFuelConsumption;
    }

    if( this.fuel < 0 ) this.fuel = 0;
    if( this.boosterFuel < 0 ) this.boosterFuel = 0;

    this.weight = MathUtils.Map( this.fuel , 0 , this.maxFuel , this.dryWeight , this.maxWeight );
  }

  private updatePositionAndSpeed(){

    var lastPosition = new Phaser.Math.Vector2(this.x,this.y);

    this.velocity.add(this.acceleration);
    this.x += this.velocity.x;
    this.y += this.velocity.y;
    this.acceleration.scale(0);

    var currentPosition = new Phaser.Math.Vector2(this.x,this.y);
    this.speed = lastPosition.distance(currentPosition);
    this.verticalSpeed = lastPosition.y - currentPosition.y;

  }

  private updateTimeAndMoney(delta:number){
    this.flightTime += delta;
  }

  public updateKeyInput(keys: any) {

    this.keys = keys;

    this.isBoosterOn = this.keys.W.isDown;
    this.isMainEngineOn = !this.keys.S.isDown;
    if (this.keys.A.isDown) this.rotation -= this.handling;
    if (this.keys.D.isDown) this.rotation += this.handling;

  }

  public applyForce(force: Force) {
    let normalizedForce: Force = force.outDiv(this.weight);
    this.acceleration.add(normalizedForce);
  }

  private loadPlayerSprites()
  {
    this.headSprite = this.scene
    .add
    .sprite(GameData.Parts.Head.Stock.ImageOffsetX,
      GameData.Parts.Head.Stock.ImageOffsetY,
      GameData.Parts.Head.Stock.ImageName);

    this.bodySprite = this.scene
    .add
    .sprite(GameData.Parts.Body.Stock.ImageOffsetX,
      GameData.Parts.Body.Stock.ImageOffsetY,
      GameData.Parts.Body.Stock.ImageName);

    this.engineSprite = this.scene
    .add
    .sprite(GameData.Parts.Engine.Stock.ImageOffsetX,
      GameData.Parts.Engine.Stock.ImageOffsetY,
      GameData.Parts.Engine.Stock.ImageName);

    this.finsSprite = this.scene
    .add
    .sprite(GameData.Parts.Fins.Stock.ImageOffsetX,
      GameData.Parts.Fins.Stock.ImageOffsetY,
      GameData.Parts.Fins.Stock.ImageName);

    this.boosterSprite = this.scene
    .add
    .sprite(GameData.Parts.Booster.Stock.ImageOffsetX,
      GameData.Parts.Booster.Stock.ImageOffsetY,
      GameData.Parts.Booster.Stock.ImageName);

    this.add([this.boosterSprite,
      this.headSprite,
      this.engineSprite,
      this.bodySprite,
      this.finsSprite]);
  }

  public debugObject()
  {
    if( this.isDebugMode ){
      var bound = this.getBounds();
      this.debugGraphics.clear();

      // bound box
      this.debugGraphics.lineStyle(1, 0xff0000);
      this.debugGraphics.strokeRectShape(bound);
      // velocity
      this.debugGraphics.lineStyle(2, 0x00ff00);
      this.debugGraphics.strokeLineShape(new Phaser.Geom.Line(this.x,this.y,this.x+this.velocity.x*4,this.y+this.velocity.y*4));
      // drag
      this.debugGraphics.lineStyle(2, 0x0000ff);
      this.debugGraphics.strokeLineShape(new Phaser.Geom.Line(this.x,this.y,this.x+this.drag.x*4,this.y+this.drag.y*4));
    }
  }

  /**
   * Getters & Setters
   */
  public get Hp():number{
    return this.hp;
  }
  public set Hp(value:number){
    this.hp = value;
  }
  public get Armor():number{
    return this.armor;
  }
  public set Armor(value:number){
    this.armor = value;
  }
  public get Weight():number{
    return this.weight;
  }
  public set Weight(value:number){
    this.weight = value;
  }
  public get Power():number{
    return this.power;
  }
  public set Power(value:number){
    this.power = value;
  }
  public get Fuel():number{
    return this.fuel;
  }
  public set Fuel(value:number){
    this.fuel = value;
  }
  public get MaxFuel():number{
    return this.maxFuel;
  }
  public set MaxFuel(value:number){
    this.maxFuel = value;
  }
  public get FuelConsumption():number{
    return this.fuelConsumption;
  }
  public set FuelConsumption(value:number){
    this.fuelConsumption = value;
  }
  public get BoosterPower():number{
    return this.boosterPower;
  }
  public set BoosterPower(value:number){
    this.boosterPower = value;
  }
  public get BoosterFuel():number{
    return this.boosterFuel;
  }
  public set BoosterFuel(value:number){
    this.boosterFuel = value;
  }
  public get MaxBoosterFuel():number{
    return this.maxBoosterFuel;
  }
  public set MaxBoosterFuel(value:number){
    this.maxBoosterFuel = value;
  }
  public get BoosterFuelConsumption():number{
    return this.boosterFuelConsumption;
  }
  public set BoosterFuelConsumption(value:number){
    this.boosterFuelConsumption = value;
  }
  public get BoosterOverheating():number{
    return this.boosterOverheating;
  }
  public set BoosterOverheating(value:number){
    this.boosterOverheating = value;
  }
  public get BoosterMaxOverheating():number{
    return this.boosterMaxTemperature;
  }
  public set BoosterMaxOverheating(value:number){
    this.boosterMaxTemperature = value;
  }
  public get Handling():number{
    return this.handling;
  }
  public set Handling(value:number){
    this.handling = value;
  }
  public get AirResistance():number{
    return this.airResistance;
  }
  public set AirResistance(value:number){
    this.airResistance = value;
  }

  public get Altitude():number{
    return this.altitude;
  }
  public get Speed():number{
    return this.speed;
  }
  public get VerticalSpeed():number{
    return this.verticalSpeed;
  }
  public get FlightTime():number{
    return this.flightTime;
  }
  public set FlightTime(time:number){
    this.flightTime = time;
  }
  public get Money():number{
    return this.totalMoney
  }
  public set Money(amount:number){
    this.totalMoney = amount
  }


}