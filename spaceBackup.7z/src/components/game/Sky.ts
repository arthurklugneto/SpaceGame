import { MathUtils } from '../../core/MathUtils';
import { GameData } from '../../core/GameData';

export class Sky extends Phaser.GameObjects.Container{

  private skySprite!:Phaser.GameObjects.Sprite;

  constructor(_scene: Phaser.Scene, _x: number, _y: number){
    super(_scene, _x, _y);

    this.skySprite = this.scene.add.sprite(0,_y,GameData.Sky.Default.ImageName);
    this.skySprite.scrollFactorX = 0;
    this.skySprite.scrollFactorY = 0.04;
    this.skySprite.scaleX = 10000;
    this.skySprite.scaleY = 10;

  }

  public updateSky(altitude:number){

  }

}
