import { GameData } from '../../core/GameData';

export class HelperRuler100Feet extends Phaser.GameObjects.Sprite
{

  constructor(_scene:Phaser.Scene,_x:number,_y:number)
  {
    super(_scene,_x,_y,GameData.Helper.Ruler100Feet.ImageName);
  }

}