import { MathUtils } from "../../core/MathUtils";

export class GuiClock extends Phaser.GameObjects.Container{

  private clockText!:Phaser.GameObjects.Text;

  private elapsedTime:number = 0;

  constructor(_scene: Phaser.Scene, _x: number, _y: number){

    super(_scene, _x, _y);

    this.clockText = _scene.add.text(_x,_y,'00:00');
    this.clockText.setBackgroundColor('#ff0000');
    this.clockText.setFontSize(40);

  }

  public setTime(timeInMilliseconds:number){
    this.elapsedTime = timeInMilliseconds;
    this.clockText.setText(MathUtils.MillisecondsToTime(timeInMilliseconds));
  }

}