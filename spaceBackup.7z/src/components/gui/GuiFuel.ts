import { MathUtils } from '../../core/MathUtils';
import { GameData } from "../../core/GameData";

export class GuiFuel extends Phaser.GameObjects.Container{

  //private text!:Phaser.GameObjects.Text;
  private fuelBody!: Phaser.GameObjects.Sprite;
  private fuelNedle!: Phaser.GameObjects.Sprite;

  constructor(_scene: Phaser.Scene, _x: number, _y: number)
  {
    super(_scene, _x, _y);

    this.fuelBody = this.scene.add.sprite(_x,_y,GameData.Gui.FuelBody.ImageName);

    this.fuelNedle =  this.scene.add.sprite(
      _x,_y,
      GameData.Gui.AtmosphereNedle.ImageName);
    this.fuelNedle.setScale(0.5);
    this.fuelBody.setScale(0.5);

    //this.text=text;
  }

  setFuel(value:number,maxValue:number)
  {
    //var needle = MathUtils.Map(this.value,0,this.maxValue,-2.6,2.6);
    var needle = MathUtils.Map(value,0,maxValue,-2.6,2.6);
    if( needle < -2.6 ) needle = -2.6;
    if( needle > 2.6 ) needle = 2.6
    this.fuelNedle.rotation = needle;
    //this.text.setText(MathUtils.Map(value,0,maxValue,0,100).toFixed(0) + '%');
  }

}